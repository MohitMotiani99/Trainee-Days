package com.pres.temporals;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class Dur {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println("DURATION");
		System.out.println("**********************************************************");
		
		LocalTime lt = LocalTime.now();
		System.out.println("Time is: "+lt);
		System.out.println();
		
		//Duration object
		System.out.println("Duration object for 3200 minutes is: "+ Duration.ofMinutes(3200));
		//ofHours
		//ofSeconds etc...
		
		// to save that duration 
		System.out.println("Adding Duration to time");
		System.out.println("Time after Adding Duration of 5 hours");
		System.out.println(lt.plus(Duration.ofHours(5)));
		
		System.out.println("Time after Adding Duration of 5 Minutes");
		System.out.println(lt.plus(Duration.ofMinutes(5)));
		
		System.out.println("Time after Adding Duration of 5 Seconds");
		System.out.println(lt.plus(Duration.ofSeconds(5)));
		
		System.out.println("Date Time after Adding Duration of 5 Days ");
		System.out.println(LocalDateTime.now().plus(Duration.ofDays(5)));
		System.out.println();
		System.out.println("Calculating Durations: ");
		System.out.println();
		System.out.println("Duration between "+LocalTime.now()+" and "+LocalTime.now().plusHours(7)+" is : "+ Duration.between(LocalTime.now(), LocalTime.now().plusHours(7)));
		System.out.println();
		System.out.println("Duration between "+LocalTime.now()+" and "+LocalTime.now().plusMinutes(2000)+" is : "+ Duration.between(LocalTime.now(), LocalTime.now().plusMinutes(2000)));
		System.out.println();
		String str = "PT12H10M";
		Duration dur = Duration.parse(str);
		//to make a duration from a valid string
		
		System.out.println("Time after adding "+str+" Duration is: "+LocalTime.now().plus(dur));
	}

}
