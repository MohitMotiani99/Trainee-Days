package com.pack.uipack;

import java.util.*;

import com.pack.*;
import com.pack.exception.DuplicateToyIdException;
import com.pack.exception.InsufficientToysException;
import com.pack.exception.InsufficientToystoDeleteException;
import com.pack.exception.NoToyFoundException;

public class Main {
   public static void main(String[] args) throws NoToyFoundException, InsufficientToystoDeleteException, CloneNotSupportedException, DuplicateToyIdException, InsufficientToysException {
	   
	   @SuppressWarnings("resource")
	Scanner sc=new Scanner(System.in);
	  
	   //creating an arraylist of dummy custs and admins
	   
	   ArrayList<Sha256> cust=new ArrayList<Sha256>();
	   
	   cust.add(new Sha256("Hritika","deltagamma"));
       cust.add(new Sha256("Neha","ilovemypiano"));
	   cust.add(new Sha256("Mohit","Sterling"));
	   cust.add(new Sha256("ggg","oooo"));
	   
       ArrayList<Sha256> admin=new ArrayList<Sha256>();
	   
	   admin.add(new Sha256("Mythili","deltagamma3"));
      
	   
	   //Asking the person to enter the login details
	   System.out.println("Please enter Username and Password");
	   String unName=sc.next();
	   String password=sc.next();
	   Sha256 person=new Sha256(unName,password);

	   //checks if the customer arraylist contains "person", logs in as customer and displays customer dashboard 
	   if(cust.contains(person))
		   {
		   CustomerService.email=unName;
		   CustomerService.pass="oooo";
		   
		   System.out.println("Logged in as a Customer");
		   while(true){
				System.out.println("1. Rent");  
				System.out.println("2. List of all toys"); 
				System.out.println("3. Search toys by name"); 
				System.out.println("4. Search toys by age range");
				System.out.println("5. Search toys by rental amount "); 
				System.out.println("6. Exit");
				System.out.println("Enter your choice");
				int choice = sc.nextInt();
				
				switch (choice) {
				case 1:
				{
					System.out.println("Enter the toy ID");
					int toyId=sc.nextInt();
					System.out.println("Enter the toy units");
					int units=sc.nextInt();
					String rent=CustomerService.rentService(toyId,units);
					System.out.println(rent);
					break;
					
				}
				case 2:
					{
						ArrayList<Toy> tlist=CustomerService.getAllToysService();
					for (Toy toy : tlist)
					{
						System.out.println(toy);
					}
				    break;
				    }
				case 3:
				 {  
					 // TODO 
					 System.out.println("Enter the toy name");
				     String toyName=sc.next();
				     ArrayList<Toy> tlist=CustomerService.searchToysbyName(toyName);
				     for (Toy toy : tlist)
						{
							System.out.println(toy);
						}
					
					
					break;
					}
				case 4:
				{   
					System.out.println("Enter the age range for which you wish to search toys");
			         int lowAge=sc.nextInt();
			         int highAge=sc.nextInt();
			     ArrayList<Toy> tlist=CustomerService.searchToysbyAgeRange(lowAge,highAge);
			     for (Toy toy : tlist)
					{
						System.out.println(toy);
					}
				
				
				break;
				}
				case 5:
				{   
					System.out.println("Enter the rental amount range for which you wish to search toys");
			         int minRentalAmount=sc.nextInt();
			         int maxRentalAmount=sc.nextInt();
			     ArrayList<Toy> tlist=CustomerService.searchToysbyRentalAmountRange(minRentalAmount,maxRentalAmount);
			     for (Toy toy : tlist)
					{
						System.out.println(toy);
					}
				
				
				break;
				}
				
				case 6:
				{
					System.out.println("Enter the toy ID and units for the toy ");
					int toyId = sc.nextInt();
					int units = sc.nextInt();
					
					String msg = CustomerService.deleteFromCart(toyId, units);
					System.out.println(msg);
					
					break;
				}
				case 7:
				{
//					ArrayList<ArrayList<Integer>> cart = CustomerService.viewCartService();
//					// TODO System.out.println(CustomerService);
//					for(ArrayList<Integer> rec:cart) {
//						System.out.println("Toy ID: "+rec.get(0)+" Number of Units : "+rec.get(1)+" Cost: "+rec.get(2));
//					}
				}
				case 8:
				{
					long bill = CustomerService.generateBillService();
					System.out.println("Bill Generated for the Rentals is : " + bill);
					break;
				}
				default:
				    {
					sc.close();
					System.out.println("Bye");
					System.exit(0);
					}
					
				}
		   }
		   
		   }
	   
	 //checks if the admin arraylist contains "person", logs in as admin and displays admin dashboard 
	   else if(admin.contains(person))    
	   {   System.out.println("Logged in as a Admin"); 
		   while(true){
			System.out.println("1. Add Toy");  
			System.out.println("2. List of toys"); 
			System.out.println("3. Update toy");
			System.out.println("4. Remove toy "); 
			System.out.println("5. Get Inventory Value");
			System.out.println("6.Get Refund Income");
			System.out.println("7. Exit");System.out.println();
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			
			switch(choice){
			case 1:
			{
				System.out.println("Enter the details of the toy");
				int toyId = sc.nextInt();
				String toyName=sc.next();
				String toyType = sc.next();
				int minAge = sc.nextInt();
				int maxAge = sc.nextInt();
				int price = sc.nextInt();
				int quantity = sc.nextInt();
				int rentalAmount = sc.nextInt();
				int refundableDeposit = sc.nextInt();

				System.out.println(AdminService.addToyService(new Toy(toyId,toyName,toyType,minAge,maxAge,price,quantity,rentalAmount,refundableDeposit)));
				break;			
				
			}
				
			case 2:
			{
				ArrayList<Toy> tlist = AdminService.getAllToysService();
				
				for (Toy toy : tlist)
				{
					System.out.println(toy);
				}
				
				break;
			}
			
			case 3:
			{
				System.out.println("Enter the toy id");
				int toyId = sc.nextInt();
					
						System.out.println("1.Update Name");
						System.out.println("2.Update Price");
						System.out.println("3.Update Type");
						System.out.println("4.Update Rental Amount ");
						System.out.println("5. Exit");
						
						System.out.println( "Enter Update Option");
						int num = sc.nextInt();
						
						switch(num)
						{
						case 1:
						{
							
							System.out.println("Enter Updated toy Name");
							String toyName = sc.next();
							System.out.println(AdminService.updateToyNameService(toyId, toyName));
							
							
						    break;
						    }
						case 2:
						{
							System.out.println("Enter the updated toy price");
							int price = sc.nextInt();
							System.out.println(AdminService.updatePriceService(toyId, price));
							break;
						}
						
						case 3:
						{
							System.out.println("Enter the updated Toy Type");
							String toyType = sc.next();
							System.out.println(AdminService.updateToyTypeService(toyId, toyType));
							break;
						}
						case 4:
						{
							System.out.println("Enter the updated rental Amount");
							int rentalAmount = sc.nextInt();
							System.out.println(AdminService.updateRentalAmountService(toyId, rentalAmount));
							
							break;
						}
						default:
						{
							//sc.close();
							System.out.println("No updatation");
							//System.exit(0);
							
						}
						}
					
//				System.out.println("Enter the updated toy price");
//				int price = sc.nextInt();
//				System.out.println(AdminService.updatePriceService(toyId, price));
//						
				break;
			}
			
			case 4:
			{
				System.out.println("Enter the toy id & number of units for the toy to remove");
				int toyId = sc.nextInt();
				int units = sc.nextInt();
				System.out.println (AdminService.removeToyService(toyId,units)); 
			
				break;
			}
			
			case 5:
			{
				System.out.println("Total Inventory value:   Rs. "+AdminService.getInventoryValueService());
				break;
			}
			case 6:
			{
			
				System.out.println("Total Rental Income:   Rs. "+AdminService.getRentalIncomeService());
				break;
			}
			
			
			default:
				{
				sc.close();
				System.out.println("Bye");
				System.exit(0);
				}
			}
			
		}
	   }
	  //if login details do not match either as a customer or as an admin
	   else
		   System.out.println("Wrong Username or Password.");

}
	
}