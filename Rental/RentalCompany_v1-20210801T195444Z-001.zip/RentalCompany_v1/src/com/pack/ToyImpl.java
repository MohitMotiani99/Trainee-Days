package com.pack;



public class ToyImpl{


}
