package com.pres.temporals;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

public class LD {

	public static void main(String[] args) {
		
		
		
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println("LocalDate Functions");
		System.out.println("**********************************************************");
		LocalDate ld = LocalDate.now();
		System.out.println("Current Date is: " + ld);
		//y-m-d
		
		System.out.println("Month for the Date is: "+ld.getMonthValue());
		System.out.println("Month Day for the Date is: "+ld.getDayOfMonth());
		System.out.println("Year for the Date is: "+ld.getYear());
		
		
		LocalDate prevDay = ld.minusDays(5);
		System.out.println("Date 5 days before the current date is: "+ prevDay);
		// gets n days back date
		
		LocalDate prevDay_w = ld.minusWeeks(5);
		System.out.println("Date 5 weeks before the current date is: "+prevDay_w);
		//gets n weeks future date
		
		LocalDate prevDay_m = ld.minusMonths(5);
		System.out.println("Date 5 months before the current date is: "+prevDay_m);
		//gets n months future date
		
		LocalDate prevDay_y = ld.minusYears(5);
		System.out.println("Date 5 years before the current date is: "+prevDay_y);
		// gets n years future date 
		System.out.println();
		LocalDate nextday = ld.plusDays(5);
		System.out.println("Date 5 days after the current date is: "+nextday);
		// gets n days future date
		
		LocalDate nextday_w = ld.plusWeeks(5);
		System.out.println("Date 5 weeks after the current date is: "+nextday_w);
		//gets n weeks future date
		
		LocalDate nextday_m = ld.plusMonths(5);
		System.out.println("Date 5 months after the current date is: "+nextday_m);
		//gets n months future date
		
		LocalDate nextday_y = ld.plusYears(5);
		System.out.println("Date 5 years after the current date is: "+nextday_y);
		// gets n years future date 
		System.out.println();
		System.out.println("Is the year in date "+ld +" a leap year? "+ld.isLeapYear());
		
		//y-m-d
		//Setting a custom date
		LocalDate ly1 = LocalDate.of(2021,7,24);
		System.out.println("Date is: "+ly1);
		
		System.out.println("Check if the date "+ld+" is after a Date 2020-5-11 : "+ld.isAfter(LocalDate.of(2020,5,11)));
		
		System.out.println("Day of the week for the date "+ld+" is :"+ld.getDayOfWeek());
		
		//Gives a period object
		System.out.println("Period from "+ld+" to "+" 2023-3-29 is: "+ld.until(LocalDate.of(2023, 3, 29)));
		System.out.println("Period from 2023-3-29 to "+ld+" is: "+LocalDate.of(2023, 3, 29).until(ld));
		
		System.out.println();
		System.out.println("Temporal Adjusters");
		System.out.println("First Date of the current Month: "+LocalDate.now().with(TemporalAdjusters.firstDayOfMonth()));
		System.out.println("First Date of the Next Month: "+LocalDate.now().with(TemporalAdjusters.firstDayOfNextMonth()));
		System.out.println("Last Date of the current month is : "+LocalDate.now().with(TemporalAdjusters.lastDayOfMonth()));
		System.out.println("First Date of the current year: "+LocalDate.now().with(TemporalAdjusters.firstDayOfYear()));
		System.out.println("First Date of the next year: "+LocalDate.now().with(TemporalAdjusters.firstDayOfNextYear()));
		System.out.println("Last Date of the current year is : "+LocalDate.now().with(TemporalAdjusters.lastDayOfYear()));
		System.out.println("Nearest Wednesday Date : "+LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.WEDNESDAY)));
		System.out.println("Latest Wednesday Date : "+LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.WEDNESDAY)));
		System.out.println("Next Wednesday Date : "+LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.WEDNESDAY)));
		System.out.println("Previous Wednesday Date : "+LocalDate.now().with(TemporalAdjusters.previous(DayOfWeek.WEDNESDAY)));
		System.out.println("Last Wednesday Date of this month : "+LocalDate.now().with(TemporalAdjusters.lastInMonth(DayOfWeek.WEDNESDAY)));
		// TemporalAdjusters
		// DayOfWeek
		//TemporalAdjusters.
		//DayOfWeek.
		
		// & many more
		
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println("**********************************************************");

	}

}
